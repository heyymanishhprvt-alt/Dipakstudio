
export interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  isCelebrity?: boolean;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface Branch {
  city: string;
  address: string;
  phone: string;
  mapUrl: string;
  isHeadOffice?: boolean;
}


import React, { useState } from 'react';

export const Booking: React.FC = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call to CRM/Email Service
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="bg-ivory min-h-screen py-32 flex items-center justify-center animate-fadeIn">
        <div className="max-w-2xl text-center space-y-8 px-6">
          <div className="w-24 h-24 bg-royalGreen rounded-full flex items-center justify-center mx-auto text-antiqueGold animate-bounce">
            <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 className="font-serif text-5xl text-charcoal leading-tight">Your Narrative <br/><span className="italic font-light">Has Begun.</span></h1>
          <p className="text-charcoal/60 font-sans text-sm tracking-widest uppercase leading-loose">
            Our Senior Creative Director has been notified. A private consultation link will be dispatched to your email within 4 business hours.
          </p>
          <button 
            onClick={() => setIsSuccess(false)}
            className="text-antiqueGold border-b border-antiqueGold font-bold text-[10px] uppercase tracking-[0.4em] pb-1 hover:text-royalGreen transition-colors"
          >
            Submit Another Commission
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-ivory min-h-screen py-32 text-royalGreen animate-fadeIn">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-24 items-start mb-32">
          <div className="lg:sticky lg:top-32 space-y-12">
            <div>
              <h3 className="font-sans text-[10px] tracking-[0.6em] uppercase text-antiqueGold mb-6 font-bold">Commission</h3>
              <h1 className="font-serif text-6xl md:text-8xl mb-8 leading-tight text-charcoal">Reserve the <br/><span className="italic font-light">Narrative</span></h1>
              <p className="text-charcoal/60 text-base leading-relaxed max-w-md font-light">
                Secure your date for a cinematic legacy. Each commission is handled personally by our creative directors to ensure the Dipak standard.
              </p>
            </div>
            
            <div className="space-y-6">
               <div className="p-8 glass-dark bg-royalGreen/5 rounded-sm border border-antiqueGold/20">
                  <p className="font-sans text-[9px] uppercase tracking-[0.3em] text-antiqueGold font-bold mb-4">Availability Notice</p>
                  <p className="text-charcoal/70 text-sm leading-relaxed">Currently accepting high-profile commissions for the 2024-25 season. Destination weddings require minimum 6 months lead time.</p>
               </div>
               
               <div className="flex items-center space-x-6">
                  <div className="w-12 h-12 rounded-full bg-royalGreen flex items-center justify-center text-antiqueGold">
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                  </div>
                  <div>
                    <p className="font-serif text-xl text-charcoal">Global Concierge</p>
                    <p className="text-[10px] uppercase tracking-widest text-antiqueGold font-bold">+91 98100 12345</p>
                  </div>
               </div>
            </div>
          </div>

          <div className="bg-white p-12 md:p-16 shadow-2xl rounded-sm border border-royalGreen/5 relative overflow-hidden">
            {isSubmitting && (
              <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-20 flex items-center justify-center">
                <div className="text-center space-y-4">
                  <div className="w-12 h-12 border-4 border-antiqueGold border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="font-sans text-[10px] uppercase tracking-[0.4em] text-antiqueGold font-bold">Encrypting Request...</p>
                </div>
              </div>
            )}
            
            <h4 className="font-serif text-3xl mb-10 text-charcoal">Event Intelligence</h4>
            <form className="space-y-8" onSubmit={handleSubmit}>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-royalGreen/40 font-bold">Full Name</label>
                  <input type="text" required className="w-full bg-transparent border-b border-royalGreen/10 py-3 focus:outline-none focus:border-antiqueGold text-sm transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-royalGreen/40 font-bold">Email Address</label>
                  <input type="email" required className="w-full bg-transparent border-b border-royalGreen/10 py-3 focus:outline-none focus:border-antiqueGold text-sm transition-colors" />
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-royalGreen/40 font-bold">Commission Type</label>
                  <select required className="w-full bg-transparent border-b border-royalGreen/10 py-3 focus:outline-none focus:border-antiqueGold text-sm transition-colors cursor-pointer">
                    <option value="">Select Experience</option>
                    <option>Heritage Wedding (Single Venue)</option>
                    <option>Grand Destination Union</option>
                    <option>Cinematic Pre-Wedding Film</option>
                    <option>Portrait Masterclass Session</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-royalGreen/40 font-bold">Primary Venue</label>
                  <input type="text" placeholder="e.g. Taj Mansingh, Delhi" className="w-full bg-transparent border-b border-royalGreen/10 py-3 focus:outline-none focus:border-antiqueGold text-sm transition-colors" />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-royalGreen/40 font-bold">Wedding Date</label>
                  <input type="date" required className="w-full bg-transparent border-b border-royalGreen/10 py-3 focus:outline-none focus:border-antiqueGold text-sm transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase tracking-widest text-royalGreen/40 font-bold">Estimated Guest Count</label>
                  <input type="number" placeholder="200 - 2000+" className="w-full bg-transparent border-b border-royalGreen/10 py-3 focus:outline-none focus:border-antiqueGold text-sm transition-colors" />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest text-royalGreen/40 font-bold">Specific Vision or Requirements</label>
                <textarea rows={4} className="w-full bg-transparent border border-royalGreen/10 p-4 focus:outline-none focus:border-antiqueGold text-sm transition-colors resize-none" placeholder="Tell us about the mood, the heritage, or any specific cultural nuances you wish to highlight..."></textarea>
              </div>

              <button 
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-royalGreen text-antiqueGold py-6 text-[10px] uppercase tracking-[0.5em] font-bold hover:bg-antiqueGold hover:text-royalGreen transition-all duration-700 shadow-xl disabled:opacity-50"
              >
                Send Commission Request
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

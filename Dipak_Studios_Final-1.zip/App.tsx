
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { Films } from './pages/Films';
import { Booking } from './pages/Booking';
import { Services } from './pages/Services';
import { Blog } from './pages/Blog';
import { About } from './pages/About';
import { Reviews } from './pages/Reviews';
import { Support } from './pages/Support';
import { ClientPortal } from './pages/ClientPortal';
import { Footer } from './components/Footer';
import { ShutterLoader } from './components/ShutterLoader';
import { AIConcierge } from './components/AIConcierge';
import { WhatsAppButton } from './components/WhatsAppButton';

export type Page = 'home' | 'films' | 'booking' | 'services' | 'blog' | 'about' | 'reviews' | 'support' | 'portal';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isLoading, setIsLoading] = useState(true);
  const [isAiOpen, setIsAiOpen] = useState(false);

  useEffect(() => {
    // Initial and page-change loader
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
      window.scrollTo(0, 0);
    }, 1500);
    return () => clearTimeout(timer);
  }, [currentPage]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <Home onNavigate={setCurrentPage} />;
      case 'films': return <Films />;
      case 'booking': return <Booking />;
      case 'services': return <Services />;
      case 'blog': return <Blog />;
      case 'about': return <About />;
      case 'reviews': return <Reviews />;
      case 'support': return <Support />;
      case 'portal': return <ClientPortal />;
      default: return <Home onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="relative min-h-screen bg-royalGreen text-ivory selection:bg-antiqueGold selection:text-royalGreen font-sans overflow-x-hidden">
      {isLoading && <ShutterLoader />}
      
      <div className={`transition-opacity duration-1000 ${isLoading ? 'opacity-0' : 'opacity-100'}`}>
        <Navbar currentPage={currentPage} onNavigate={setCurrentPage} />
        
        <main className="min-h-screen">
          {renderPage()}
        </main>

        <Footer onNavigate={setCurrentPage} />
      </div>

      {/* Persistent Global Actions */}
      <WhatsAppButton />
      
      <div className="fixed bottom-8 right-8 z-50 flex flex-col items-end space-y-4">
        <button 
          onClick={() => setIsAiOpen(!isAiOpen)}
          className="w-14 h-14 rounded-full bg-antiqueGold text-royalGreen flex items-center justify-center shadow-2xl hover:scale-110 transition-transform duration-300 group"
          title="AI Wedding Visionary"
        >
          <svg className={`w-6 h-6 transition-transform duration-500 ${isAiOpen ? 'rotate-45' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </button>

        <button 
          onClick={() => setCurrentPage('booking')}
          className="bg-ivory text-royalGreen px-8 py-4 rounded-full font-bold text-[10px] tracking-[0.3em] uppercase shadow-2xl hover:bg-antiqueGold hover:text-royalGreen transition-all transform hover:-translate-y-1 hidden md:block"
        >
          Reserve Date
        </button>
      </div>

      {/* AI visioning portal */}
      {isAiOpen && (
        <div className="fixed inset-0 z-[60] bg-charcoal/90 backdrop-blur-2xl flex items-center justify-center p-6 animate-fadeIn">
          <div className="w-full max-w-4xl relative">
            <button 
              onClick={() => setIsAiOpen(false)}
              className="absolute -top-14 right-0 text-antiqueGold hover:text-ivory transition-colors text-[10px] tracking-[0.4em] uppercase font-bold"
            >
              Exit Visionary [ESC]
            </button>
            <AIConcierge />
          </div>
        </div>
      )}
    </div>
  );
};

export default App;

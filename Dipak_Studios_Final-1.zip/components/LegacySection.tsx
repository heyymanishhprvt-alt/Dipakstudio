
import React from 'react';

export const LegacySection: React.FC = () => {
  return (
    <section id="heritage" className="py-32 bg-ivory text-royalGreen overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-24 items-center">
        <div className="relative">
          <div className="absolute -top-12 -left-12 w-48 h-48 border-l border-t border-antiqueGold/30" />
          <div className="overflow-hidden shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&q=80&w=800" 
              alt="Vintage Heritage" 
              className="w-full grayscale hover:grayscale-0 transition-all duration-1000 scale-105 hover:scale-100"
            />
          </div>
          <div className="absolute -bottom-10 -right-10 bg-royalGreen text-ivory p-10 shadow-2xl">
            <span className="font-serif text-7xl block mb-2 leading-none">62</span>
            <span className="font-sans text-[9px] tracking-[0.4em] uppercase text-antiqueGold font-bold">Years of Pure Artistry</span>
          </div>
        </div>

        <div className="space-y-10">
          <h3 className="font-sans text-[10px] tracking-[0.5em] uppercase text-antiqueGold font-bold">The Custodian of Memories</h3>
          <h2 className="font-serif text-4xl md:text-7xl leading-[1.1] text-charcoal">
            A Journey Through <br />
            <span className="italic font-light text-royalGreen">The Golden Hour</span>
          </h2>
          <p className="font-sans text-sm md:text-base text-charcoal/70 leading-relaxed max-w-lg font-light">
            Founded in 1962, Dipak Studios pioneered the art of cinematic wedding storytelling in India. We believe that a wedding isn't just an event—it's a living archive of culture, emotion, and an enduring legacy. Our lenses have witnessed the evolution of Indian grandeur, preserving the silent promises of generations.
          </p>
          <div className="grid grid-cols-2 gap-12 pt-10 border-t border-royalGreen/10">
            <div>
              <h4 className="font-serif text-3xl mb-1 text-charcoal">25k+</h4>
              <p className="font-sans text-[9px] tracking-[0.3em] uppercase opacity-50 font-bold">Unions Immortalized</p>
            </div>
            <div>
              <h4 className="font-serif text-3xl mb-1 text-charcoal">Iconic</h4>
              <p className="font-sans text-[9px] tracking-[0.3em] uppercase opacity-50 font-bold">Bollywood Portfolio</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

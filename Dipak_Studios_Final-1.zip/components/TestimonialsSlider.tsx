
import React, { useState } from 'react';

const testimonials = [
  { name: "Aditi & Sahil", loc: "The Taj Palace, Delhi", year: "2023", quote: "Dipak Studios didn't just document our wedding; they archived the soul of our union. Looking at the frames, we don't just see photos—we feel the atmosphere of that day." },
  { name: "The Kapoor Family", loc: "Udaipur City Palace", year: "2022", quote: "A legacy of 60 years shows in every frame. Their ability to handle high-profile ceremonies with such grace and cinematic precision is why they are the only choice for our family." },
  { name: "Riya & Varun", loc: "Destination Tuscany", year: "2023", quote: "Bespoke service from the first meeting. They understood our global aesthetic perfectly and delivered a cinematic highlight that rivals the silver screen." }
];

export const TestimonialsSlider: React.FC = () => {
  const [active, setActive] = useState(0);

  return (
    <section className="py-32 bg-ivory text-royalGreen relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <header className="text-center mb-24">
          <h3 className="font-sans text-[10px] tracking-[0.6em] uppercase text-antiqueGold mb-6 font-bold">Client Narratives</h3>
          <h2 className="font-serif text-5xl md:text-7xl text-charcoal leading-tight">Voices of the <span className="italic font-light">Legacy</span></h2>
        </header>

        <div className="relative">
          <div className="overflow-hidden">
            <div 
              className="flex transition-transform duration-1000 ease-in-out" 
              style={{ transform: `translateX(-${active * 100}%)` }}
            >
              {testimonials.map((t, i) => (
                <div key={i} className="min-w-full px-4 md:px-20 text-center">
                  <p className="font-serif text-2xl md:text-4xl text-charcoal/80 italic leading-relaxed mb-12 max-w-4xl mx-auto">
                    "{t.quote}"
                  </p>
                  <div className="space-y-2">
                    <p className="font-serif text-2xl text-charcoal">{t.name}</p>
                    <p className="text-[10px] uppercase tracking-[0.4em] text-antiqueGold font-bold">{t.loc} • {t.year}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-center space-x-6 mt-16">
            {testimonials.map((_, i) => (
              <button 
                key={i} 
                onClick={() => setActive(i)}
                className={`h-1.5 transition-all duration-500 rounded-full ${active === i ? 'w-12 bg-antiqueGold' : 'w-3 bg-antiqueGold/20 hover:bg-antiqueGold/40'}`}
                aria-label={`Slide ${i + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

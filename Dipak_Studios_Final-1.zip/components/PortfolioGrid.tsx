
import React from 'react';
import { PORTFOLIO } from '../constants';

export const PortfolioGrid: React.FC = () => {
  return (
    <section id="portfolio" className="py-24 px-6 bg-charcoal">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div>
            <h3 className="font-sans text-xs tracking-[0.4em] uppercase text-antiqueGold mb-4">Curated Moments</h3>
            <h2 className="font-serif text-4xl md:text-6xl text-ivory">The Collection</h2>
          </div>
          <div className="flex space-x-6 overflow-x-auto pb-4 md:pb-0 font-sans text-[10px] tracking-widest uppercase text-ivory/40">
            {['All', 'Celebrity', 'Destination', 'Cinematic'].map(cat => (
              <button key={cat} className="hover:text-antiqueGold border-b border-transparent hover:border-antiqueGold pb-1 transition-all">
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PORTFOLIO.map((item) => (
            <div 
              key={item.id} 
              className="group relative h-[600px] overflow-hidden rounded-sm cursor-none"
            >
              <img 
                src={item.imageUrl} 
                alt={item.title} 
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-royalGreen/40 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-8">
                <div className="morphic-card p-6 transform translate-y-10 group-hover:translate-y-0 transition-transform duration-700">
                  <span className="font-sans text-[10px] tracking-widest uppercase text-antiqueGold mb-2 block">{item.category}</span>
                  <h4 className="font-serif text-2xl text-ivory mb-4">{item.title}</h4>
                  <div className="w-12 h-px bg-antiqueGold group-hover:w-full transition-all duration-700" />
                </div>
              </div>
              {item.isCelebrity && (
                <div className="absolute top-4 right-4 bg-antiqueGold text-royalGreen px-3 py-1 rounded-full font-sans text-[8px] tracking-widest uppercase font-bold shadow-lg">
                  Celebrity Choice
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

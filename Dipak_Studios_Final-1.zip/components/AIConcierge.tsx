
import React, { useState, useRef, useEffect } from 'react';
import { getWeddingAdvice } from '../services/gemini';
import { ChatMessage } from '../types';

export const AIConcierge: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Greetings. I am the Visionary Assistant. Describe your dream wedding, and I'll help you visualize the cinematic frames we could capture together." }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setIsTyping(true);

    const advice = await getWeddingAdvice(userMsg);
    setMessages(prev => [...prev, { role: 'model', text: advice || "I'm sorry, I couldn't process that vision. Shall we try again?" }]);
    setIsTyping(false);
  };

  return (
    <section id="experience" className="py-24 px-6 bg-royalGreen">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h3 className="font-sans text-xs tracking-[0.4em] uppercase text-antiqueGold mb-4">AI Visionary</h3>
          <h2 className="font-serif text-4xl md:text-6xl text-ivory">Design Your Frame</h2>
          <p className="mt-6 text-ivory/60 font-sans text-sm max-w-lg mx-auto leading-relaxed">
            Harness the power of AI and our 60-year legacy to plan your visual narrative. Tell us about your venue, outfit colors, or mood.
          </p>
        </div>

        <div className="morphic-card rounded-xl overflow-hidden shadow-2xl flex flex-col h-[500px]">
          {/* Chat Header */}
          <div className="p-4 border-b border-antiqueGold/20 bg-antiqueGold/5 flex items-center space-x-3">
            <div className="w-3 h-3 rounded-full bg-antiqueGold animate-pulse" />
            <span className="font-sans text-[10px] tracking-widest uppercase text-antiqueGold font-bold">Live Visionary Concierge</span>
          </div>

          {/* Chat Body */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-4 rounded-lg font-sans text-sm leading-relaxed ${
                  m.role === 'user' 
                  ? 'bg-antiqueGold text-royalGreen ml-12' 
                  : 'bg-ivory/5 text-ivory/90 border border-antiqueGold/10 mr-12'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-ivory/5 p-4 rounded-lg flex space-x-1">
                  <div className="w-1 h-1 bg-antiqueGold rounded-full animate-bounce" />
                  <div className="w-1 h-1 bg-antiqueGold rounded-full animate-bounce [animation-delay:-.3s]" />
                  <div className="w-1 h-1 bg-antiqueGold rounded-full animate-bounce [animation-delay:-.5s]" />
                </div>
              </div>
            )}
          </div>

          {/* Chat Input */}
          <div className="p-4 bg-charcoal/50 border-t border-antiqueGold/20 flex space-x-4">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="e.g., A sunset wedding at a farm house in Gurgaon..."
              className="flex-1 bg-transparent border border-ivory/20 rounded-full px-6 py-2 text-ivory text-sm focus:outline-none focus:border-antiqueGold transition-colors"
            />
            <button 
              onClick={handleSend}
              className="bg-antiqueGold text-royalGreen px-6 rounded-full font-sans text-[10px] tracking-widest uppercase font-bold hover:bg-ivory transition-colors"
            >
              Consult
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

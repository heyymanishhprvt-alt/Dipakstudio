
import React from 'react';

interface LogoProps {
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({ className = "h-12" }) => {
  return (
    <div className={`relative flex items-center ${className}`}>
      <svg
        viewBox="0 0 250 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="h-full w-auto"
      >
        <defs>
          <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#C9A44C" />
            <stop offset="25%" stopColor="#C9A44C" />
            <stop offset="50%" stopColor="#F7F5EF" />
            <stop offset="75%" stopColor="#C9A44C" />
            <stop offset="100%" stopColor="#C9A44C" />
            <animate 
              attributeName="x1" 
              values="-100%;100%" 
              dur="4s" 
              repeatCount="indefinite" 
            />
            <animate 
              attributeName="x2" 
              values="0%;200%" 
              dur="4s" 
              repeatCount="indefinite" 
            />
          </linearGradient>
        </defs>
        
        {/* Butterfly Icon (Recreated from original design) */}
        <g className="shining-gold-svg">
          <path d="M45,20 C50,15 65,10 85,25 C85,25 75,35 60,35 C45,35 45,20 45,20 Z" />
          <path d="M45,22 C40,15 25,10 5,25 C5,25 15,35 30,35 C45,35 45,22 45,22 Z" />
          <path d="M45,45 L45,15 C45,15 47,12 47,10 C47,8 43,8 43,10 C43,12 45,15 45,15" stroke="url(#goldGradient)" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="45" cy="18" r="2.5" />
          <circle cx="45" cy="25" r="3" />
          <circle cx="45" cy="33" r="3" />
          <circle cx="45" cy="41" r="3" />
          <path d="M43,8 C40,4 35,5 35,5" stroke="url(#goldGradient)" strokeWidth="0.5" fill="none" />
          <path d="M47,8 C50,4 55,5 55,5" stroke="url(#goldGradient)" strokeWidth="0.5" fill="none" />
        </g>

        {/* Dipak Typography */}
        <text
          x="10"
          y="85"
          className="font-sans font-bold text-[58px]"
          fill="url(#goldGradient)"
          style={{ letterSpacing: '-0.02em' }}
        >
          Dipak
        </text>

        {/* STUDIOS Typography */}
        <text
          x="105"
          y="95"
          className="font-sans font-medium text-[24px]"
          fill="url(#goldGradient)"
          style={{ letterSpacing: '0.45em' }}
        >
          STUDIOS
        </text>
      </svg>
    </div>
  );
};


import React from 'react';
import { Logo } from './Logo';

export const ShutterLoader: React.FC = () => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-charcoal overflow-hidden">
      {/* 12-Blade Shutter Container */}
      <div className="absolute inset-0 z-0">
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute inset-0 bg-royalGreen border-l border-antiqueGold/5"
            style={{
              clipPath: 'polygon(50% 50%, 0 0, 100% 0)',
              transformOrigin: '50% 50%',
              transform: `rotate(${i * 30}deg)`,
              animation: 'apertureClose 1.5s cubic-bezier(0.85, 0, 0.15, 1) forwards'
            }}
          />
        ))}
      </div>

      {/* Central Flash and Logo */}
      <div className="z-10 flex flex-col items-center animate-pulse">
        <Logo className="h-20 md:h-24 transition-transform duration-1000 scale-110" />
        <div className="mt-8 overflow-hidden">
          <div className="h-[2px] w-24 bg-antiqueGold/20 relative">
             <div className="absolute inset-0 bg-antiqueGold animate-loadingBar" />
          </div>
        </div>
        <span className="mt-4 text-[8px] uppercase tracking-[0.8em] text-antiqueGold/40 font-bold">Calibrating Vision</span>
      </div>

      <style>{`
        @keyframes apertureClose {
          0% { clip-path: polygon(50% 50%, 50% 50%, 50% 50%); transform: rotate(0deg) scale(2); }
          50% { clip-path: polygon(50% 50%, 0 0, 100% 0); transform: rotate(15deg) scale(1); }
          100% { clip-path: polygon(50% 50%, 50% 50%, 50% 50%); transform: rotate(30deg) scale(0); opacity: 0; }
        }
        @keyframes loadingBar {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};


import React from 'react';

export const Hero: React.FC = () => {
  return (
    <section className="relative h-screen w-full overflow-hidden flex items-center justify-center">
      {/* Background Media - Production Ready Video Support */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&q=80&w=1920" 
          className="w-full h-full object-cover brightness-[0.3]"
          alt="Cinematic Wedding Narrative"
        />
        {/* Simulating a real cinematic grain/video overlay */}
        <div className="absolute inset-0 bg-black/20 mix-blend-overlay pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-b from-royalGreen/80 via-transparent to-royalGreen" />
        
        {/* Dynamic Lens Flare Overlay */}
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-antiqueGold/5 rounded-full blur-[120px] animate-pulse pointer-events-none" />
      </div>

      <div className="relative z-10 text-center px-6 max-w-6xl mx-auto">
        <div className="mb-10 overflow-hidden">
          <h2 className="font-sans text-[10px] md:text-xs tracking-[0.8em] uppercase text-antiqueGold mb-4 font-bold opacity-0 animate-fadeIn" style={{ animationDelay: '0.8s', animationFillMode: 'forwards' }}>
            Visionaries of the Eternal Union
          </h2>
        </div>
        
        <h1 className="font-serif text-5xl md:text-8xl lg:text-9xl mb-12 leading-[0.85] tracking-tight opacity-0 animate-fadeIn" style={{ animationDelay: '1.2s', animationFillMode: 'forwards' }}>
          Archiving <span className="italic font-light">Legacy</span><br />
          <span className="gold-gradient-text font-bold">Since 1962.</span>
        </h1>

        <div className="flex flex-col md:flex-row items-center justify-center space-y-8 md:space-y-0 md:space-x-12 opacity-0 animate-fadeIn" style={{ animationDelay: '1.6s', animationFillMode: 'forwards' }}>
          <p className="max-w-xs font-sans text-[11px] md:text-xs text-ivory/50 uppercase tracking-[0.2em] leading-relaxed text-center md:text-left font-medium">
            India's most storied wedding films for Bollywood icons and global royalty.
          </p>
          <div className="w-px h-16 bg-antiqueGold/20 hidden md:block" />
          <div className="flex space-x-4">
            <button className="group relative overflow-hidden px-10 py-5 bg-antiqueGold text-royalGreen tracking-[0.3em] uppercase text-[10px] font-bold transition-all hover:bg-ivory shadow-2xl">
              Commission Us
            </button>
            <button className="px-10 py-5 border border-antiqueGold/30 text-antiqueGold tracking-[0.3em] uppercase text-[10px] font-bold hover:bg-antiqueGold/10 transition-all">
              The Film Gallery
            </button>
          </div>
        </div>
      </div>

      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center">
        <span className="text-[8px] uppercase tracking-[0.5em] text-antiqueGold/40 mb-6 font-bold animate-pulse">Unveil the Cinematic Narrative</span>
        <div className="w-px h-16 bg-gradient-to-b from-antiqueGold/40 to-transparent" />
      </div>
    </section>
  );
};

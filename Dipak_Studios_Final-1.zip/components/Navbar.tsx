
import React, { useState, useEffect } from 'react';
import { Page } from '../App';
import { Logo } from './Logo';

interface NavbarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems: { label: string; id: Page }[] = [
    { label: 'Films', id: 'films' },
    { label: 'Experiences', id: 'services' },
    { label: 'Legacy', id: 'about' },
    { label: 'Journal', id: 'blog' },
    { label: 'Portal', id: 'portal' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${isScrolled ? 'bg-royalGreen/95 backdrop-blur-xl py-4 shadow-2xl border-b border-antiqueGold/10' : 'bg-transparent py-8'}`}>
      <div className="max-w-[1400px] mx-auto px-6 flex justify-between items-center">
        {/* Brand Logo */}
        <button 
          onClick={() => onNavigate('home')}
          className="flex flex-col text-left group transition-transform hover:scale-105 duration-300"
        >
          <Logo className="h-10 md:h-12" />
        </button>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center space-x-10">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`font-sans text-[10px] tracking-[0.3em] uppercase transition-all duration-300 hover:text-antiqueGold ${currentPage === item.id ? 'text-antiqueGold border-b border-antiqueGold/30 pb-1' : 'text-ivory/70'}`}
            >
              {item.label}
            </button>
          ))}
          <button 
            onClick={() => onNavigate('booking')}
            className="bg-antiqueGold/10 border border-antiqueGold/40 text-antiqueGold px-6 py-2 rounded-sm text-[9px] tracking-[0.3em] uppercase hover:bg-antiqueGold hover:text-royalGreen transition-all"
          >
            Book Session
          </button>
        </div>

        {/* Mobile Toggle */}
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden text-antiqueGold p-2"
        >
          {mobileMenuOpen ? (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M6 18L18 6M6 6l12 12" /></svg>
          ) : (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 8h16M4 16h16" /></svg>
          )}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      <div className={`fixed inset-0 top-[80px] z-40 bg-royalGreen transition-transform duration-500 transform ${mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'} lg:hidden p-10 flex flex-col items-center space-y-8`}>
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => { onNavigate(item.id); setMobileMenuOpen(false); }}
            className="font-serif text-3xl text-ivory/80 hover:text-antiqueGold"
          >
            {item.label}
          </button>
        ))}
        <button 
          onClick={() => { onNavigate('booking'); setMobileMenuOpen(false); }}
          className="mt-8 font-sans text-xs tracking-widest text-antiqueGold border-b border-antiqueGold pb-2"
        >
          Start Your Story
        </button>
      </div>
    </nav>
  );
};


import React from 'react';
import { PortfolioItem, Branch } from './types';

export const BRANCHES: Branch[] = [
  { 
    city: 'Delhi', 
    address: 'Lajpat Nagar', 
    phone: '+91 98100 12345',
    mapUrl: 'https://www.google.com/maps/search/Dipak+Studios+Lajpat+Nagar+Delhi'
  },
  { 
    city: 'Gurgaon', 
    address: 'Golf Course Road', 
    phone: '+91 98100 54321',
    mapUrl: 'https://www.google.com/maps/search/Dipak+Studios+Gurgaon+Golf+Course+Road'
  },
  { 
    city: 'Faridabad', 
    address: 'Neelam Chowk', 
    phone: '+91 129 4022666',
    mapUrl: 'https://www.google.com/maps/search/Dipak+Studios+Faridabad+Neelam+Chowk',
    isHeadOffice: true
  },
];

export const PORTFOLIO: PortfolioItem[] = [
  { id: '1', title: 'Deepika & Ranveer', category: 'Celebrity Wedding', imageUrl: 'https://picsum.photos/seed/wedding1/800/1000', isCelebrity: true },
  { id: '2', title: 'The Royal Jaipur Vows', category: 'Destination', imageUrl: 'https://picsum.photos/seed/wedding2/800/1000' },
  { id: '3', title: 'Vicky & Katrina', category: 'Celebrity Wedding', imageUrl: 'https://picsum.photos/seed/wedding3/800/1000', isCelebrity: true },
  { id: '4', title: 'Modern Elegance in Delhi', category: 'Portrait', imageUrl: 'https://picsum.photos/seed/wedding4/800/1000' },
  { id: '5', title: 'Sunset at Udaipur', category: 'Cinematic', imageUrl: 'https://picsum.photos/seed/wedding5/800/1000' },
  { id: '6', title: 'Candid Moments', category: 'Emotional', imageUrl: 'https://picsum.photos/seed/wedding6/800/1000' },
];
